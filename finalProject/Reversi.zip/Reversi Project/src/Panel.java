import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.*;

public class Panel extends JPanel implements Runnable
{
    private int cellSize;
    private int pieceSize;
    private Board board = null;
    private int humanColor;
    private int cpuColor;
    private boolean waitingInput = false;
    private boolean finished = false;
    public static final int HUMAN = 100;
    public static final int CPU = 200;
    private int lastMoveIndex;
    
    public Panel(int cellSize, int startPlayer)
    {
        board = new Board();                  
                                
        if (startPlayer == HUMAN)
            this.humanColor = Board.BLACK;
        else
            this.humanColor = Board.WHITE;
        
        this.cpuColor = 3 - this.humanColor;
        
        this.cellSize = cellSize;
        this.pieceSize = (int)(cellSize * 0.75);
        this.setDoubleBuffered(true);
        int screenSize = (2 + Board.BOARD_SIZE) * cellSize;                
        this.setPreferredSize(new Dimension(screenSize, screenSize));                                          
        this.addMouseWatcher();
        
        UIManager.put("OptionPane.noButtonText", "NO");
        UIManager.put("OptionPane.yesButtonText", "YES");        
     }            
    
    private boolean isFinished()
    {       
        return board.checkEnd();       
    }
    
    private boolean isHumanTurn()
    {                    
        return humanColor == board.getCurrentPlayer();                
    }
    
    private void doLogic()
    {            
        if (isFinished())
        {
            finished = true;
            return;
        }
        
        
        if (isHumanTurn())
        {   
            if (waitingInput)
                return;
                        
            ArrayList<Move> moves = board.getAllMoves(humanColor);
            if (moves.get(0).getFlipSquares() == null)
            {                
                board.makeMove(moves.get(0));                
                waitingInput = false;
            }            
            else    
            {
                waitingInput = true;
            }            
        }
        
        else               
        {   
            int maxDepth = 6; 
            boolean solve = board.getPhase() == Board.PHASE_ENDGAME;
            
            CountDownLatch signal =  new CountDownLatch(1);
            Minimax AI = new Minimax(board.cloneBoard(), maxDepth, signal, solve);
                   
            new Thread(AI).start(); 
            try
            {
                signal.await();
            }
            catch(InterruptedException exception)
            {
                exception.printStackTrace();
            }
                        
            Move mv = AI.getBestFound();
            board.makeMove(mv);    
            //repaint();
            lastMoveIndex = mv.getIdx();
            int x=lastMoveIndex;
            int y=x/10;
            System.out.println("Computer's Move: Row:" + y + "	Column:" + x%10);                        
        }
        
    }
      
    private void doInput(int index)
    {                                       
        if (isHumanTurn())
        {
            int[] cells = board.getCells();
            if (cells[index] != Board.EMPTY)
                return;
            
            ArrayList<Integer> flips = board.getFlips(index, humanColor);            
            if (flips.size() > 0)
            {                          
                Move mv = new Move();
                mv.setFlipSquares(flips);
                mv.setIdx(index);
               
                int x=index;
                int y=x/10;
                System.out.println("\nPlayer Move: Row:" + y + "	Column:" + x%10);
                
                mv.setPlayer(humanColor);                
                board.makeMove(mv); 
                lastMoveIndex = index;
                repaint();
                waitingInput = false;                
            }
        }
    }
        
    public void startNewGame()
    {
        board = new Board();
        finished = false;
        waitingInput = false;
        lastMoveIndex = -666;
       
        new Thread(this).start();
    }
    
    public void run()
    {
        while (! finished)
        {   
         try
            {
        	Thread.sleep (500);                        
        	this.doLogic();
            this.repaint();
                                  
           
                Thread.sleep(20L);
            }
            catch (InterruptedException exception)
            {}                                                         
        }
        
     
        int human = board.countDiscs(humanColor);
        int cpu = board.countDiscs(cpuColor);  
        int empty = Board.BOARD_SIZE * Board.BOARD_SIZE - (human + cpu);        
        String msg = null;
        
        if (human  > cpu)
        {
            human += empty;
            msg = "You are the winner!!\nYour points: " + human + " - Computer's Points:" + cpu + "!";
            
        }
        else if (human < cpu)
        {
            cpu += empty;
            msg = "Computer is the winner!! \nYour points: " + human + " - Computer's points:" + cpu + "!";            
        }
        else
            msg = "Game is a draw!";
        
        msg += "\nWant to play another game?";
        int x = JOptionPane.showConfirmDialog(null, msg, "Game Over", JOptionPane.YES_NO_OPTION);
        
        if (x == 0)
            startNewGame();
    }
    
    private void drawGUI(Graphics g)
    {                
        Graphics2D g2D = (Graphics2D) g;
        g2D.setStroke(new BasicStroke(1.5f));
        
        Color bg = new Color(0, 130, 0);  
        setBackground(bg);
        
        int w = Board.BOARD_SIZE * cellSize;
        int origin = cellSize;
                
        g.setColor(Color.black);
          
        //Draw Rows
        for (int i = 0; i < Board.BOARD_SIZE + 1; i++)
        {
        	g.drawLine(origin, i * cellSize + origin, origin + w, i * cellSize + origin);
        }
        
        //Draw Columns
        for (int i = 0; i < Board.BOARD_SIZE + 1; i++)
        {
            g.drawLine(i * cellSize + origin, origin, i * cellSize + origin, w + origin);
        }
        
        //Header color
        g.setColor(Color.white);
    
        //headers
        String[] headers = new String[]{"A","B","C","D","E","F","G","H"};
        for (int i = 0; i < Board.BOARD_SIZE; i++)
            g.drawString(headers[i], cellSize * i + (int)(origin * 1.5), (int)(cellSize * 0.75));
        
       
        for (int i = 0; i < Board.BOARD_SIZE; i++)
            g.drawString("" + (i + 1), (int)(cellSize * 0.6), cellSize * i + (int)(origin * 1.5));     
                                                 
    }
    
    private void drawScore(Graphics g)
    {
        //score
        g.setColor(Color.yellow);
        g.setFont(new Font(null, Font.BOLD, 15));
        int wd = board.countDiscs(Board.WHITE);
        int bd = board.countDiscs(Board.BLACK);
        
        g.drawString("White: " + wd, cellSize * 1, (int)(cellSize * 9.5));
        g.drawString("Black: " + bd, cellSize * 8, (int)(cellSize * 9.5));
               
    }
    private void drawBoard(Graphics g)
    {
        int[] cells = board.getCells();                
        int gameCols = Board.BOARD_SIZE;
        int hiddenCols = gameCols + 2;
        int mid = (cellSize - pieceSize)/2;
        
        for (int i = hiddenCols; i < cells.length - hiddenCols; i++) 
        {
            int col = i % hiddenCols;
            int row = i / hiddenCols;
            
            if ((col != 0) && (col != hiddenCols - 1))
            {
                int piece = cells[i];
                if (piece == Board.EMPTY)
                    continue;
                Piece p = new Piece(cells[i], pieceSize);
                p.draw(g, col * cellSize + mid, row * cellSize + mid);
            }
        }
        
        
        if (lastMoveIndex > 0)
        {
            g.setColor(Color.yellow);
            int col = lastMoveIndex % hiddenCols;
            int row = lastMoveIndex / hiddenCols;
            
            g.drawRect(col * cellSize, row * cellSize, cellSize, cellSize);
        }
    }
        
    private void drawMoves(Graphics g)
    {
        ArrayList<Move> moves = board.getAllMoves(humanColor);
        if (isHumanTurn() && moves.get(0).getFlipSquares() != null)
        {
            g.setColor(new Color(0, 0, 0, 80));
            for (Move mv : moves)
            {
                int idx = mv.getIdx();
                int col = idx % 10;
                int row = idx /10;
                                
                g.fillOval(col * cellSize + cellSize/2, row * cellSize + cellSize/2, cellSize/8, cellSize/8);
            }
        }
    }
           
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
            
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        this.drawGUI(g);     
        this.drawBoard(g);
        this.drawScore(g);
        this.drawMoves(g);
    }
    
    //mouse
    private void addMouseWatcher()
    {
        this.addMouseListener(new MouseAdapter()
        {
            public void mousePressed(MouseEvent e) 
            {                                
                int col = e.getX()/cellSize;
                int row = e.getY()/cellSize;
                int index = row * (Board.BOARD_SIZE  + 2) + col;
                                               
                if ((row > 0 && row < 9) && (col > 0 && col < 9))
                    doInput(index);                                                
            }          
        });
    }
	
    public static void main (String[] args) throws Exception
    {                                                                    
        Panel panel = new Panel(60, HUMAN);
        JFrame window = new JFrame("Reversi");
        window.getContentPane().add(panel);
        window.setResizable(false);
        window.pack();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);     
        new Thread(panel).start();                                                                                                      
    }    
}
