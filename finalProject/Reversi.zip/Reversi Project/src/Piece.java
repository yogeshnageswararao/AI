import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class Piece
{
 private int color;
 private int size;
 
 public Piece(int color, int size)
 {
  this.color = color;
  this.size = size;
 }
 
 public void draw(Graphics g, int x, int y)
 {                                            
  Color col = null;
  if (color == Board.WHITE)
   col = Color.white; 

  else
   col = Color.black;

   
  g.setColor(col);
  g.fillOval(x, y, size, size);          
 
 }
} 
