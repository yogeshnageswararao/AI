import java.util.ArrayList;

public class Heuristics
{
    private static final int[] cornerIndexes = new int[]{11, 18, 81, 88};
    private static final int[] xIndexes = new int[]{22, 27, 72, 77};
    private static final int[] cIndexes = new int[]{12, 21, 17, 28, 71, 82, 78, 87};
    
    private static final int[] squareValues = new int[]
    {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 100, -10, 11, 6, 6, 11, -10, 100, 0, 
        0, -10, -20, 1, 2, 2, 1, -20, -10, 0, 
        0, 10, 1, 5, 4, 4, 5, 1, 10, 0, 
        0, 6, 2, 4, 2, 2, 4, 2, 6, 0, 
        0, 6, 2, 4, 2, 2, 4, 2, 6, 0, 
        0, 10, 1, 5, 4, 4, 5, 1, 10, 0, 
        0, -10, -20, 1, 2, 2, 1, -20, -10, 0, 
        0, 100, -10, 11, 6, 6, 11, -10, 100, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
    };
    public static int mobility (int player, Board board)
    {
        return board.getAllMoves(player).size();      
    }
 
    public static int mobilityDiff (int player, Board board)
    {           
        return mobility(player, board) - mobility(board.getOpponent(player), board);
    }
    
    public static int potentialMobility(int player, Board board)
    {
        int opponent = board.getOpponent(player);
        int[] cells = board.getCells();
        int mob = 0;
        
        for (int i = 10; i < 90; i++)
        {
            int col = i % 10;
            if (col != 0 && col != 9)
            {
                if (cells[i] == opponent)
                {
                    for (Integer dir : Board.DIRECTIONS)
                    {
                        int around = dir + i;
                        if (cells[around] == Board.EMPTY && cells[around] != Board.WALL)
                        {
                            mob++;
                            break;
                        }
                    }
                }
            }
        }
        return mob;
    }
    
    public static int potentialMobilityDiff(int player, Board board)
    {
     return potentialMobility(player, board) - potentialMobility(board.getOpponent(player), board);
    }
         
    public static int cornerSquares (int player, Board board)
    {   
        int corners = 0;  
        int[] cells = board.getCells();
        
        for(int i = 0; i < cornerIndexes.length; i++)
            if (cells[cornerIndexes[i]] == player)
                corners++;
        return corners;
    }
 
    public static int cornerSquaresDiff (int player, Board board)
    {
        return cornerSquares(player, board) - cornerSquares(board.getOpponent(player), board);
    }
    
    public static int badXSquares (int player, Board board)
    {
        int x = 0;
        int[] cells = board.getCells();

        for (int i = 0; i < 4; i++)
            if ((cells[cornerIndexes[i]] != player) && (cells[xIndexes[i]] == player))
                      x++;

        return x;
    }
    
    public static int badXSquaresDiff (int player, Board board)
    {
        return badXSquares(player, board) - badXSquares(board.getOpponent(player), board);
    }
    
    public static int badCSquares (int player, Board board)
    {  
        int c = 0;
        int[] cells = board.getCells();
        
        int corner = 0;                             
        for (int i = 0; i < cIndexes.length; i+= 2)
        {
            if (cells[cornerIndexes[corner++]] != player)
            {
                if (cells[cIndexes[i]] == player)
                    c++;
                if (cells[cIndexes[i + 1]] == player)
                    c++;               
            }
        }
                
        return c;
    }
    
    public static int badCSquaresDiff (int player, Board board)
    {
        return badCSquares(player, board) - badCSquares(board.getOpponent(player), board);
    }
        
    public static int discsDiff (int player, Board board)
    {
        int playerDiscs = board.countDiscs(player);
  int opponentDiscs = board.countDiscs(board.getOpponent(player));
  
  return playerDiscs - opponentDiscs;        
    }
    
    public static void scoreMoves(ArrayList<Move> moves)
    {
        for (Move mv : moves)
        {
            mv.setEval(squareValues[mv.getIdx()]);
        }
    }
    
    public static float eval(int player, Board board)
    {
        float value = 0.0f;
        int phase = board.getPhase();
    
        if (phase == Board.PHASE_OPENING)
        {                        
            value = 100 * mobilityDiff(player, board) + 100 * potentialMobilityDiff(player, board)
            + 800 * cornerSquaresDiff(player, board) 
            - 200 * badXSquaresDiff(player, board) - 200 * badCSquaresDiff(player, board);        
                                  
        }
        else if (phase == Board.PHASE_MIDGAME)
        {                        
            value = 100 * mobilityDiff(player, board) + 100 * potentialMobilityDiff(player, board)
            + 900 * cornerSquaresDiff(player, board) 
            - 250 * badXSquaresDiff(player, board) - 200 * badCSquaresDiff(player, board); 
        }
        else if (phase == Board.PHASE_ENDGAME)
        {
            value = discsDiff(player, board);
        }
        else
        {
            System.out.println("Error in calculating the heuristics");
        }
                        
        return value;
    }
}
