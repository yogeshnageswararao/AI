import java.util.*;
import java.util.concurrent.*;

public class Minimax implements Runnable
{
    private CountDownLatch doneSignal;    
    private int maxDepth;
    private int calls;    
    private Move bestFound;
    private Board board;
    private static float INFINITY = Float.MAX_VALUE/1000;    
    private boolean solve = false;
    private Comparator<Move> comparator = Collections.reverseOrder(new MoveComparator());
           
    public Minimax (Board board, int maxDepth, CountDownLatch doneSignal, boolean solve)
    {
        this.board = board;        
        this.bestFound = new Move();
        bestFound.setPlayer(board.getCurrentPlayer());
        this.maxDepth = maxDepth; 
        this.doneSignal = doneSignal;                
        this.solve = solve;
    }
    
    public Move getBestFound()
    {       
        return this.bestFound;
    }
    public void run()
    {        
        float val = minimax(board, -INFINITY, INFINITY, 0);
        System.out.println("\nNumber of times the minimax algorithm is called"+ ": " + calls);
        System.out.println("Obtained highest points for this move: " + val);
        
        doneSignal.countDown();        
    }
    
    private float minimax(Board board, float alpha, float beta, int depth)
    {
        calls++;                        
        int currentPlayer = board.getCurrentPlayer();
        
        if (board.checkEnd())
        {                        
            int bd = board.countDiscs(Board.BLACK);
            int wd = board.countDiscs(Board.WHITE);
            
            if ((bd > wd) && currentPlayer == Board.BLACK)
            {                
                return INFINITY/10;
            }
            else if ((bd < wd) && currentPlayer == Board.BLACK)
            {                
                return -INFINITY/10;
            }
            else if ((bd > wd) && currentPlayer == Board.WHITE)
            {                
                return -INFINITY/10;
            }
            else if ((bd < wd) && currentPlayer == Board.WHITE)
            {                
                return INFINITY/10;
            }
            else 
            {                
                return 0;
            }
        }
        if (!solve)
        {
            if (depth == maxDepth)
                return Heuristics.eval(currentPlayer, board);
        }
        
        ArrayList<Move> moves = board.getAllMoves(currentPlayer);
        if (moves.size() > 1)
        {
            Heuristics.scoreMoves(moves);        
            Collections.sort(moves, comparator);
        }
        
        for (Move mv : moves)
        {                                    
            board.makeMove(mv);            
            float score = - minimax(board, -beta, -alpha, depth + 1);           
            board.undoMove(mv);             
            
            if(score > alpha)
            {  
                alpha = score;                
				if (depth == 0)
				{
					this.bestFound.setFlipSquares(mv.getFlipSquares());
					this.bestFound.setIdx(mv.getIdx());        
					this.bestFound.setPlayer(mv.getPlayer());                              
				}
            }
            
            if (alpha >= beta)
                break;                
            
        }            
        return alpha;
    }  
}
