import java.util.*;

public class Board
{
   public static final int BLACK = 1;
   public static final int WHITE = 2;
   public static final int EMPTY = 0;
   public static final int WALL = 5;
   public static final int BOARD_SIZE = 8;
   public static final int[] DIRECTIONS = { -11, -10, -9, -1, 1, 9, 10, 11}; 
   public static final int PHASE_OPENING = 100;
   public static final int PHASE_MIDGAME = 200;
   public static final int PHASE_ENDGAME = 300;
    
   private int emptyCells;        
   private int phase;
   private int currentPlayer = BLACK;
   private int[] cells = new int[(BOARD_SIZE + 2) * (BOARD_SIZE + 2)];
 
   public Board()
   {
        this.currentPlayer = BLACK;
  
        cells[44] = WHITE;
        cells[55] = WHITE;
        cells[45] = BLACK;
        cells[54] = BLACK;        
        
        emptyCells = BOARD_SIZE * BOARD_SIZE - 4;
        
        for (int i = 0; i < cells.length; i++) 
        {
            int col = i % 10;
            int row = i / 10;
            
            if (col == 0 || col == 9)
                cells[i] = WALL;
            if (row == 0 || row == 9)
                cells[i] = WALL;
        }
        
        phase = PHASE_OPENING;                            
   }
    
    public void toogleCurrentPlayer()
    {
        currentPlayer = getOpponent(currentPlayer);
    }
                
    public void setEmptyCells(int emp)
    {
        this.emptyCells = emp;
    }

    public boolean checkEnd()
    {
        boolean endGame = false;
        
        if (emptyCells == 0)
            endGame = true;
        else if ((getAllMoves(BLACK).get(0).getFlipSquares() == null) && 
                 (getAllMoves(WHITE).get(0).getFlipSquares() == null))
        {
            endGame = true;
        }                
        
        return endGame;
    }
    
    public Board cloneBoard()
    {
        Board b = new Board();
        for (int i = 0; i < this.cells.length; i++)
            b.cells[i] = this.cells[i];
        
        b.phase = this.phase;
        b.currentPlayer = this.currentPlayer;
        b.emptyCells = this.emptyCells;        
        
        return b;
    }
        
    public int getEmptyCells()
    {
        return this.emptyCells;
    }
    
    public int getPhase()
    {
        return this.phase;
    }
    
    public int getCurrentPlayer()
    {
        return this.currentPlayer;
    }
    
    public int getOpponent(int player)
    {
        return 3 - player;
    }

    public int[] getCells()
    {
        return this.cells;
    }
       
    public ArrayList<Move> getAllMoves(int player)
    {
        ArrayList<Move> moves = new ArrayList<Move>();
        
        for (int i = 10; i < 90; i++) 
        {
            int col = i % 10;
            
            if (col != 0 && col != 9)            
            {
                if (cells[i] == EMPTY)
                {
                    ArrayList<Integer> flips = getFlips(i, player);                    
                    if (flips.size() > 0)
                    {
                        Move mv = new Move();
                        mv.setFlipSquares(flips);
                        mv.setIdx(i);                        
                        mv.setPlayer(player);
                        moves.add(mv);
                    }
                }
            }
        }                                     
        
        if (moves.size() == 0)
        {
            Move mv = new Move();
            mv.setPlayer(getOpponent(player));
            moves.add(mv);
        }
        return moves;
    }
    
    public ArrayList<Integer> getFlips(int idx, int player)
    {        
        int opponent = getOpponent(player);
        ArrayList<Integer> flips = new ArrayList<Integer>();
                      
        for (Integer dir : DIRECTIONS)
        {
           int distance = 1;
           int tempIdx = idx;
                        
           while (cells[tempIdx += dir] == opponent)            
               distance++;
                                                
           if ((cells[tempIdx] == player) && (distance > 1)) 
           {               
               while (distance-- > 1)
               {                    
                   tempIdx -= dir;
                   flips.add(tempIdx);
               }                            
           }            
         }
        return flips;
    }
    
    public void updatePhase()
    {
        if (emptyCells > 45)
            phase = PHASE_OPENING;
        else if(emptyCells < 15)
            phase = PHASE_ENDGAME;
        else 
            phase = PHASE_MIDGAME; 
    }
    
    public void makeMove (Move move)
    {                    
        int player = move.getPlayer();        
        ArrayList<Integer> flips = move.getFlipSquares();
        
        if (flips != null)
        {                                   
            int idx = move.getIdx();                    
            cells[idx] = player;
            for (Integer flip : flips)
                cells[flip] = player;        
                                  
            emptyCells--;    
            this.updatePhase();           
        }
        this.toogleCurrentPlayer();                    
     }
    
    public void undoMove (Move move)
    {                    
        int player = move.getPlayer();        
        ArrayList<Integer> flips = move.getFlipSquares();
        int opponent = getOpponent(player);
        
        if (flips != null)
        {
            int idx = move.getIdx();
                        
            cells[idx] = EMPTY;
            for (Integer flip : flips)
                cells[flip] = opponent;
            
            emptyCells++;                                         
            this.updatePhase();
        }
        this.toogleCurrentPlayer();                    
    }
    
    public int countDiscs(int player)
    {
        int discs = 0;
        for (int i = 10; i < 90; i++) 
        {
            int col = i % 10;
            
            if (col != 0 && col != 9)
            {
                if (cells[i] == player)                
                    discs++;                
            }            
        }
        return discs;
    }
}
