import java.util.*;

public class Move
{
    private ArrayList<Integer> flipSquares;
    private int idx;
    private int player;
    private int eval;
    
    public ArrayList<Integer> getFlipSquares()
    {
       return flipSquares;
    }

    public void setEval(int eval)
    {
        this.eval = eval;
    }

    public int getEval()
    {
        return this.eval;
    }

    public int getPlayer()
    {
        return this.player;
    }

    public void setPlayer(int player)
    {
        this.player = player;
    }

    public int getIdx()
    {
       return idx;
    }

   public void setFlipSquares(ArrayList<Integer> flipSquares)
   {
       this.flipSquares = flipSquares;
   }

   public void setIdx(int idx)
   {
       this.idx = idx;
   }
}

class MoveComparator implements Comparator<Move>
{
    public int compare(Move move1, Move move2)
    {
        if (move1.getEval() > move2.getEval())
            return 1;
        else if (move1.getEval() < move2.getEval())
            return -1;
        else 
            return 0;
    }

}
